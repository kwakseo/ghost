import React from "react";

class Root extends React.Component {
  render() {
    return (
      <div>
        Root
      </div>
    )
    ;
  }
}

export default Root;